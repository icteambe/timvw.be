﻿using System.Linq;
using Sokoban.Model.Messages;
using Sokoban.Infrastructure;
using Sokoban.Model;
using Sokoban.Resources;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Threading;
using System;

namespace Sokoban.ViewModels
{
    public class GameViewModel : ViewModel, IListener<BoardChanged>, IListener<LevelChanged>, IListener<LevelCompleted>, IListener<GameCompleted>
    {
        const int CanvasWidth = 30;
        const int CanvasHeight = 30;

        Game game;
        int level;
        double opacity;

        public ICommand PlayerLeft { get; private set; }
        public ICommand PlayerRight { get; private set; }
        public ICommand PlayerUp { get; private set; }
        public ICommand PlayerDown { get; private set; }
        public ICommand GoToLevel { get; private set; }

        public GameViewModel()
        {
            CreateCommands();
            SubscribeToInterestingMessages();
            CreateAndBeginGame();
        }

        void CreateCommands()
        {
            PlayerLeft = new DelegateCommand(o => game.MovePlayerLeft());
            PlayerRight = new DelegateCommand(o => game.MovePlayerRight());
            PlayerUp = new DelegateCommand(o => game.MovePlayerUp());
            PlayerDown = new DelegateCommand(o => game.MovePlayerDown());
            GoToLevel = new DelegateCommand(o => BeginLevel((int)o));
        }

        void SubscribeToInterestingMessages()
        {
            var messageBus = ServiceLocator.Instance.MessageBus;
            messageBus.Subscribe<BoardChanged>(this);
            messageBus.Subscribe<LevelChanged>(this);
            messageBus.Subscribe<LevelCompleted>(this);
            messageBus.Subscribe<GameCompleted>(this);
        }

        void CreateAndBeginGame()
        {
            var gameRepository = ServiceLocator.Instance.GameRepository;
            game = gameRepository.Get(@"debug.xml");
            game.Begin(1);
        }

        void BeginLevel(int level)
        {
            DoLongRunningWork(() => game.Begin(level));
        }

        void DoLongRunningWork(Action action)
        {
            Opacity = 1;
            RaisePropertyChangedImmediately("Opacity");
            new Thread(() => { action(); Opacity = 0; }).Start();
        }

        public double Opacity
        {
            get { return opacity; }
            set { opacity = value; RaisePropertyChanged("Opacity"); }
        }

        void IListener<BoardChanged>.Handle(BoardChanged message)
        {
            RaisePropertyChanged(string.Empty);
        }

        void IListener<LevelChanged>.Handle(LevelChanged message)
        {
            Level = game.Level.Number;
        }

        void IListener<LevelCompleted>.Handle(LevelCompleted message)
        {
            MessageBox.Show("Congratulations, you completed this level");
        }

        void IListener<GameCompleted>.Handle(GameCompleted message)
        {
            MessageBox.Show("Congratulations, you completed this game");
        }

        public IEnumerable<CellViewModel> Cells
        {
            get { return game.Level.Board.Cells.Select(cell => new CellViewModel(cell)); }
        }

        public int ColumnCount
        {
            get { return game.Level.Board.ColumnCount; }
        }

        public int RowCount
        {
            get { return game.Level.Board.RowCount; }
        }

        public int CellWidth
        {
            get { return CanvasWidth; }
        }

        public int CellHeight
        {
            get { return CanvasHeight; }
        }

        public int BoardWidth
        {
            get { return ColumnCount * CellWidth; }
        }

        public int BoardHeight
        {
            get { return RowCount * CellHeight; }
        }

        public IEnumerable<int> AvailableLevels
        {
            get { for (var i = 1; i <= game.AvailableLevels; ++i) yield return i; }
        }

        public int Level
        {
            get { return level; }
            set { level = value; RaisePropertyChanged("Level"); }
        }
    }
}