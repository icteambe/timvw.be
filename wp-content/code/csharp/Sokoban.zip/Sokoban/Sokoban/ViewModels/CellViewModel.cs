﻿using Sokoban.Model;
using Sokoban.Infrastructure;
using System.Windows;
using Sokoban.Views;
using Sokoban.Model.Messages;
using Sokoban.Resources;
using System.Windows.Controls;

namespace Sokoban.ViewModels
{
    public class CellViewModel : ViewModel, IListener<PieceChanged>
    {
        readonly Cell cell;

        public CellViewModel(Cell cell)
        {
            this.cell = cell;
            ServiceLocator.Instance.MessageBus.Subscribe<PieceChanged>(this);
        }

        void IListener<PieceChanged>.Handle(PieceChanged message)
        {
            RaisePropertyChanged(string.Empty);
        }

        public double Scale
        {
            get { return 0.3; }
        }

        public Visibility FloorCanvasVisible
        {
            get { return cell.IsFloor ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility GoalCanvasVisible
        {
            get { return cell.IsGoal ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility SpaceCanvasVisible
        {
            get { return cell.IsSpace ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility PlayerCanvasVisible
        {
            get { return cell.HoldsPlayer ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility WallCanvasVisible
        {
            get { return cell.HoldsWall ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility BoxCanvasVisible
        {
            get { return cell.HoldsBox ? Visibility.Visible : Visibility.Collapsed; }
        }
    }
}