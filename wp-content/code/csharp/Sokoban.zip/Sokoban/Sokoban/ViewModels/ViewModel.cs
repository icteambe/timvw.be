﻿using System.ComponentModel;
using System.Windows;

namespace Sokoban.ViewModels
{
    public class ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        protected void RaisePropertyChanged(string propertyName)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() => RaisePropertyChangedImmediately(propertyName));
        }

        protected void RaisePropertyChangedImmediately(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
