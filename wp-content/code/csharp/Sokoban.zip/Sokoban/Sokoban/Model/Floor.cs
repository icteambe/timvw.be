﻿using Sokoban.Infrastructure;

namespace Sokoban.Model
{
    public class Floor : Cell
    {
        public Floor(Position position, IMessageBus messageBus)
            : base(position, messageBus)
        {
        }
    }
}
