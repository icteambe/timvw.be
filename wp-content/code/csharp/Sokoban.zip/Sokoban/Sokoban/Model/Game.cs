﻿using Sokoban.Infrastructure;
using Sokoban.Model.Messages;

namespace Sokoban.Model
{
    public class Game
    {
        string Name { get; set; }
        public int AvailableLevels { get; private set; }
        int LevelNumber { get; set; }
        IBoardRepository BoardRepository { get; set; }
        IMessageBus MessageBus { get; set; }
        Level level;

        public Game(string name, int availableLevels, IBoardRepository boardRepository, IMessageBus messageBus)
        {
            Name = name;
            AvailableLevels = availableLevels;
            BoardRepository = boardRepository;
            MessageBus = messageBus;
        }

        public Level Level
        {
            get { return level; }
            private set { level = value; MessageBus.Publish<LevelChanged>(); }
        }

        public void Begin(int levelNumber)
        {
            LevelNumber = levelNumber;
            LoadAndInitializeLevel();
        }

        void LoadAndInitializeLevel()
        {
            Level = new Level(Name, LevelNumber, BoardRepository, MessageBus);
            Level.Initialize();
        }

        public void MovePlayerUp()
        {
            MovePlayer(Direction.Up);
        }

        public void MovePlayerDown()
        {
            MovePlayer(Direction.Down);
        }

        public void MovePlayerLeft()
        {
            MovePlayer(Direction.Left);
        }

        public void MovePlayerRight()
        {
            MovePlayer(Direction.Right);
        }

        void MovePlayer(Direction direction)
        {
            Level.MovePlayer(direction);

            if (!Level.IsComplete) return;
            MessageBus.Publish<LevelCompleted>();

            LevelNumber++;
            if (MoreLevelsAreAvailable())
            {
                LoadAndInitializeLevel();
                return;
            }
            MessageBus.Publish<GameCompleted>();
        }

        bool MoreLevelsAreAvailable()
        {
            return LevelNumber <= AvailableLevels;
        }
    }
}
