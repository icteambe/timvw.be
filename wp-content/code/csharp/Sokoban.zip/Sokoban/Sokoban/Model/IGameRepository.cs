﻿namespace Sokoban.Model
{
    public interface IGameRepository
    {
        Game Get(string name); 
    }
}
