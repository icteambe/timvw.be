﻿namespace Sokoban.Model.Language
{
    public interface IBuildBoardAndRowAndCell : IBuildBoard, IBuildRow, IBuildCell
    {
    }
}
