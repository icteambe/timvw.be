﻿namespace Sokoban.Model.Language
{
    public interface IBuildRow
    {
        IBuildBoardAndRowAndCell AddSpace();
        IBuildBoardAndRowAndCell AddFloor();
        IBuildBoardAndRowAndCell AddGoal();
        IBuildBoardAndRowAndCell AddNewRow();
    }
}
