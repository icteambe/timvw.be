﻿namespace Sokoban.Model.Language
{
    public interface IBuildCell
    {
        IBuildBoardAndRow WithPlayer();
        IBuildBoardAndRow WithBox();
        IBuildBoardAndRow WithWall();
    }
}
