﻿namespace Sokoban.Model.Language
{
    public interface IBuildBoard
    {
        Board Build();
    }
}
