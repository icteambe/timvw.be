﻿namespace Sokoban.Model.Language
{
    public interface IBuildBoardAndRow : IBuildBoard, IBuildRow
    {
    }
}
