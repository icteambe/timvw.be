﻿using Sokoban.Infrastructure;

namespace Sokoban.Model
{
    public class Space : Cell
    {
        public Space(Position position, IMessageBus messageBus)
            : base(position, messageBus)
        {
        }
    }
}
