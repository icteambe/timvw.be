﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sokoban.Model
{
    public class Board
    {
        readonly Cell[][] cells;

        public Board(Cell[][] cells)
        {
            this.cells = cells;
        }

        public IEnumerable<Cell> Cells
        {
            get { return cells.SelectMany(aRow => aRow.AsEnumerable<Cell>()); }
        }

        public int ColumnCount
        {
            get { return Cells.Max(cell => cell.Position.X) + 1; }
        }

        public int RowCount
        {
            get { return Cells.Max(cell => cell.Position.Y) + 1; }
        }

        public Cell GetAdjacentCell(Piece piece, Direction direction)
        {
            var hostingCell = GetHostingCell(piece);
            return GetAdjacentCell(hostingCell, direction);
        }

        public Cell GetHostingCell(Piece piece)
        {
            return Cells
                .Where(aCell => ReferenceEquals(aCell.Piece, piece))
                .SingleOrDefault();
        }

        public Cell GetAdjacentCell(Cell cell, Direction direction)
        {
            var adjacentPosition = cell.Position.GetAdjacent(direction);
            return GetCell(adjacentPosition);
        }

        public Cell GetCell(Position position)
        {
            return Cells
                .Where(aCell => aCell.Position == position)
                .SingleOrDefault();
        }
    }
}