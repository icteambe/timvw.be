﻿using System;
using Sokoban.Infrastructure;
using Sokoban.Model.Messages;

namespace Sokoban.Model
{
    public abstract class Cell
    {
        readonly Position position;
        readonly IMessageBus messageBus;
        Piece piece;

        public Cell(Position position, IMessageBus messageBus)
        {
            this.position = position;
            this.messageBus = messageBus;
        }

        public Position Position
        {
            get { return position; }
        }

        public Piece Piece
        {
            get { return piece; }
            set { piece = value; messageBus.Publish(new PieceChanged(this)); }
        }

        public bool HoldsPiece
        {
            get { return !ReferenceEquals(Piece, null); }
        }

        bool HoldsPieceOfType(Type type)
        {
            if (!HoldsPiece) return false;
            return Piece.GetType().IsAssignableFrom(type);
        }

        public bool HoldsWall
        {
            get { return HoldsPieceOfType(typeof(Wall)); }
        }

        public bool HoldsBox
        {
            get { return HoldsPieceOfType(typeof(Box)); }
        }

        public bool HoldsPlayer
        {
            get { return HoldsPieceOfType(typeof(Player)); }
        }

        bool IsOfType(Type type)
        {
            return this.GetType().IsAssignableFrom(type);
        }

        public bool IsGoal
        {
            get { return IsOfType(typeof(Goal)); }
        }

        public bool IsSpace
        {
            get { return IsOfType(typeof(Space)); }
        }

        public bool IsFloor
        {
            get { return IsOfType(typeof(Floor)); }
        }
    }
}
