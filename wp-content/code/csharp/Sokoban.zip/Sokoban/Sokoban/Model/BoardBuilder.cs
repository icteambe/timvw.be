﻿using System.Collections.Generic;
using Sokoban.Model.Language;
using System;
using System.Linq;
using Sokoban.Infrastructure;

namespace Sokoban.Model
{
    public class BoardBuilder : IBuildBoard, IBuildCell, IBuildRow, IBuildBoardAndRow, IBuildBoardAndRowAndCell
    {
        private readonly List<List<Cell>> rows = new List<List<Cell>>();
        private List<Cell> currentRow = new List<Cell>();

        private readonly List<Position> wallPositions = new List<Position>();
        private readonly List<Position> boxPositions = new List<Position>();
        private Position playerPosition;

        private readonly IMessageBus messageBus;

        public BoardBuilder(IMessageBus messageBus)
        {
            this.messageBus = messageBus;
        }

        private Position NextPosition
        {
            get { return new Position(currentRow.Count, rows.Count); }
        }

        private Position CurrentPosition
        {
            get { return new Position(NextPosition.X - 1, NextPosition.Y); }
        }

        public IBuildBoardAndRowAndCell AddNewRow()
        {
            if (currentRow.Count <= 0) return this;
            rows.Add(currentRow);
            currentRow = new List<Cell>();
            return this;
        }

        public IBuildBoardAndRowAndCell AddSpace()
        {
            currentRow.Add(new Space(NextPosition, messageBus));
            return this;
        }

        public IBuildBoardAndRowAndCell AddFloor()
        {
            currentRow.Add(new Floor(NextPosition, messageBus));
            return this;
        }

        public IBuildBoardAndRowAndCell AddGoal()
        {
            currentRow.Add(new Goal(NextPosition, messageBus));
            return this;
        }

        private Board Build()
        {
            var cells = CreateCellArraysFromRowsAndCurrentRow();
            var board = new Board(cells);

            CreatePieces(board, wallPositions, aBoard => new Wall(aBoard));
            CreatePieces(board, boxPositions, aBoard => new Box(aBoard));
            CreatePiece(board, playerPosition, aBoard => new Player(aBoard));

            return board;
        }

        private Cell[][] CreateCellArraysFromRowsAndCurrentRow()
        {
            var cellArray = new Cell[rows.Count + 1][];
            int columns = rows.Max(row => row.Count);

            for (var i = 0; i < rows.Count; ++i) cellArray[i] = CreateCellArrayFromRow(columns, rows[i]);
            cellArray[rows.Count] = CreateCellArrayFromRow(columns, currentRow);

            return cellArray;
        }

        private Cell[] CreateCellArrayFromRow(int columns, List<Cell> row)
        {
            Cell[] cellArray = new Cell[columns];
            for (var i = 0; i < row.Count; ++i) cellArray[i] = row[i];
            for (var i = row.Count; i < columns; ++i) cellArray[i] = new Space(new Position(i, row[0].Position.Y), messageBus);
            return cellArray;
        }

        private void CreatePieces(Board board, IEnumerable<Position> positions, Func<Board, Piece> pieceCreator)
        {
            foreach (Position position in positions) CreatePiece(board, position, pieceCreator);
        }

        private void CreatePiece(Board board, Position position, Func<Board, Piece> pieceCreator)
        {
            var newPiece = pieceCreator(board);
            board.GetCell(position).Piece = newPiece;
        }

        IBuildBoardAndRow IBuildCell.WithPlayer()
        {
            playerPosition = CurrentPosition;
            return this;
        }

        IBuildBoardAndRow IBuildCell.WithBox()
        {
            boxPositions.Add(CurrentPosition);
            return this;
        }

        IBuildBoardAndRow IBuildCell.WithWall()
        {
            wallPositions.Add(CurrentPosition);
            return this;
        }

        Board IBuildBoard.Build()
        {
            return Build();
        }
    }
}
