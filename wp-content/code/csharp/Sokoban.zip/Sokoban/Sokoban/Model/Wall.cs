﻿namespace Sokoban.Model
{
    public class Wall : Piece
    {
        public Wall(Board board)
            : base(board)
        {
        }

        public override bool Move(Direction direction)
        {
            return false;
        }
    }
}
