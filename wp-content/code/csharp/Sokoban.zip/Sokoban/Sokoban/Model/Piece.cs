﻿namespace Sokoban.Model
{
    public abstract class Piece
    {
        readonly Board board;

        public Piece(Board board)
        {
            this.board = board;
        }

        protected Cell GetHostingCell()
        {
            return board.GetHostingCell(this);
        }

        protected Cell GetAdjacentCell(Direction direction)
        {
            return board.GetAdjacentCell(this, direction);
        }

        protected void ChangeHost(Cell cell)
        {
            var currentHost = GetHostingCell();
            currentHost.Piece = null;
            cell.Piece = this;
        }

        public string Name
        {
            get { return this.ToString(); }
        }

        public override string ToString()
        {
            return this.GetType().Name;
        }

        public abstract bool Move(Direction direction);
    }
}
