﻿using Sokoban.Infrastructure;

namespace Sokoban.Model.Messages
{
    public class PlayerChanged : Message
    {
    }
}
