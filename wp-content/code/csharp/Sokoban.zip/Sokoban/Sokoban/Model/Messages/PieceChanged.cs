﻿using Sokoban.Infrastructure;

namespace Sokoban.Model.Messages
{
    public class PieceChanged : Message
    {
        public Cell Source { get; private set; }

        public PieceChanged(Cell source)
        {
            Source = source;
        }
    }
}
