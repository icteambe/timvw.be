﻿namespace Sokoban.Model
{
    public interface IBoardRepository
    {
        Board GetBoard(string gameName, int level);
    }
}
