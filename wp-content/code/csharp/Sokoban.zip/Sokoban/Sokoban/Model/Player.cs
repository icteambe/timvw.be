﻿namespace Sokoban.Model
{
    public class Player : Piece
    {
        public Player(Board board)
            : base(board)
        {
        }

        public override bool Move(Direction direction)
        {            
            var adjacentCell = GetAdjacentCell(direction);
            if (ReferenceEquals(adjacentCell, null)) return false;
            if (!adjacentCell.HoldsPiece) { ChangeHost(adjacentCell); return true; };
            if (!adjacentCell.HoldsBox) return false;
            var adjacentBox = adjacentCell.Piece;
            if(!adjacentBox.Move(direction))return false;
            ChangeHost(adjacentCell);
            return true;
        }
    }
}
