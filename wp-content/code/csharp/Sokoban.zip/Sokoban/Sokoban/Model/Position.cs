﻿using System;
namespace Sokoban.Model
{
    public class Position
    {
        readonly int x;
        readonly int y;

        public Position(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int X
        {
            get { return x; }
        }

        public int Y
        {
            get { return y; }
        }

        public override string ToString()
        {
            return string.Format("{0},{1}", Y, X);
        }

        public override int GetHashCode()
        {
            return ToString().GetHashCode();
        }

        public override bool Equals(object obj)
        {
            return InternalEquals(this, obj as Position);
        }

        public static bool operator ==(Position instance1, Position instance2)
        {
            return InternalEquals(instance1, instance2);
        }

        public static bool operator !=(Position instance1, Position instance2)
        {
            return !(instance1 == instance2);
        }

        static bool InternalEquals(Position instance1, Position instance2)
        {
            if (ReferenceEquals(instance1, instance2)) return true;
            if(ReferenceEquals(instance1,null))return false;
            if (ReferenceEquals(instance2, null)) return false;
            if (instance1.X != instance2.X) return false;
            if (instance1.Y != instance2.Y) return false;
            return true;
        }

        public Position GetAdjacent(Direction direction)
        {
            switch(direction)
            {
                case Direction.Down: return new Position(X, Y + 1);
                case Direction.Up: return new Position(X, Y - 1);
                case Direction.Left: return new Position(X - 1, Y);
                case Direction.Right: return new Position(X + 1, Y);
                default: throw new ArgumentException(string.Format("Unsupported direction: {0}", direction));
            }
        }
    }
}