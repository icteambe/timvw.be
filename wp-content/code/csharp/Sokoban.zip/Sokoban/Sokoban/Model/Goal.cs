﻿using Sokoban.Infrastructure;

namespace Sokoban.Model
{
    public class Goal : Cell
    {
        public Goal(Position position, IMessageBus messageBus)
            : base(position, messageBus)
        {
        }
    }
}
