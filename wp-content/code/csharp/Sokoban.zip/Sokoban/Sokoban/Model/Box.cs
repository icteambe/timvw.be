﻿namespace Sokoban.Model
{
    public class Box : Piece
    {
        public Box(Board board)
            : base(board)
        {
        }

        public override bool Move(Direction direction)
        {
            var adjacenCell = GetAdjacentCell(direction);
            if (ReferenceEquals(adjacenCell, null)) return false;
            if (adjacenCell.HoldsPiece) return false;
            ChangeHost(adjacenCell);
            return true;
        }
    }
}
