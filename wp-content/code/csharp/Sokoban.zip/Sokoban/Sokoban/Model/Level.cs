﻿using System.Linq;
using Sokoban.Infrastructure;
using Sokoban.Model.Messages;

namespace Sokoban.Model
{
    public class Level
    {
        readonly string name;
        readonly int number;
        readonly IBoardRepository boardRepository;
        readonly IMessageBus messageBus;
        Board board;
        Player player;

        public Level(string name, int number, IBoardRepository boardRepository, IMessageBus messageBus)
        {
            this.name = name;
            this.number = number;
            this.boardRepository = boardRepository;
            this.messageBus = messageBus;
        }

        public void Initialize()
        {
            GetBoard();
            LocatePlayer();
        }

        void GetBoard()
        {
            Board = boardRepository.GetBoard(name, number);
        }

        void LocatePlayer()
        {
            Player = board.Cells
                .Where(aCell => aCell.HoldsPlayer)
                .Select(aCell => (Player)aCell.Piece)
                .Single();
        }

        public int Number
        {
            get { return number; }
        }

        public Board Board
        {
            get { return board; }
            private set { board = value; messageBus.Publish(new BoardChanged());}
        }

        public Player Player
        {
            get { return player; }
            private set { player = value; messageBus.Publish(new PlayerChanged());}
        }

        public bool IsComplete
        {
            get
            {
                var boxesNotOnGoal = board.Cells
                    .Where(aCell => aCell.HoldsBox && !aCell.IsGoal)
                    .Select(aCell => aCell.Piece);

                return !boxesNotOnGoal.Any();
            }
        }

        public bool MovePlayer(Direction direction)
        {
            return player.Move(direction);
        }
    }
}
