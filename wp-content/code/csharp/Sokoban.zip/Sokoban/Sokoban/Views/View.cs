﻿using System.Windows.Controls;

namespace Sokoban.Views
{
    public class View : UserControl
    {
    }
}