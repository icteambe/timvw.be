﻿using Sokoban.ViewModels;

namespace Sokoban.Views
{
    public partial class CellView : View
    {
        public CellView()
        {
            InitializeComponent();
        }
   }
}