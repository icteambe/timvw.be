﻿using System.Windows;
using Sokoban.ViewModels;

namespace Sokoban.Views
{
    public partial class GameView
    {
        public GameView()
        {
            InitializeComponent();
            GoButton.Click += GoButton_Click;
        }

        void GoButton_Click(object sender, RoutedEventArgs e)
        {
            var vm = (GameViewModel) DataContext;
            vm.GoToLevel.Execute(vm.Level);
        }
    }
}