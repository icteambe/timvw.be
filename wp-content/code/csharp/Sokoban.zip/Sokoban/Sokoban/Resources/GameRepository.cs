﻿using Sokoban.Model;
using System.Linq;
using System.Xml.Linq;
using System;
using System.Windows;
using Sokoban.Infrastructure;

namespace Sokoban.Resources
{
    public class GameRepository : IGameRepository
    {
        readonly IMessageBus messageBus;

        public GameRepository(IMessageBus messageBus)
        {
            this.messageBus = messageBus;
        }

        public Game Get(string name)
        {
            var info = Application.GetResourceStream(new Uri(string.Format("Sokoban;component/Resources/Levels/{0}", name), UriKind.Relative));
            var doc = XDocument.Load(info.Stream);
            var levelCount = doc.Descendants("track").Count();
            return new Game(name, levelCount, new BoardRepository(messageBus), messageBus);
        }
    }
}
