﻿using Microsoft.Practices.Unity;
using Sokoban.Infrastructure;
using Sokoban.Model;

namespace Sokoban.Resources
{
    public class BootsTrapper
    {
        readonly IUnityContainer container = new UnityContainer();

        public void Run()
        {
            InitializeContainer();
            InitializeServiceContainer();
        }

        void InitializeContainer()
        {
            container.RegisterInstance<IMessageBus>(container.Resolve<MessageBus>());
            container.RegisterType<IBoardRepository, BoardRepository>();
            container.RegisterType<IGameRepository, GameRepository>();
        }

        void InitializeServiceContainer()
        {
            ServiceLocator.Instance = container.Resolve<ServiceLocator>();
            App.Current.Resources.Add("ServiceLocator", ServiceLocator.Instance);
        }
    }
}