﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Windows;
using Sokoban.Model;
using Sokoban.Model.Language;
using Sokoban.Infrastructure;

namespace Sokoban.Resources
{
    public class BoardRepository : IBoardRepository
    {
        static readonly Dictionary<string, Action<IBuildRow>> cellActions = new Dictionary<string, Action<IBuildRow>>();
        static readonly Dictionary<string, Action<IBuildBoardAndRowAndCell>> pieceActions = new Dictionary<string, Action<IBuildBoardAndRowAndCell>>();
        readonly IMessageBus messageBus;

        public BoardRepository(IMessageBus messageBus)
        {
            this.messageBus = messageBus;
        }

        static BoardRepository()
        {
            cellActions.Add("w", aRow => aRow.AddFloor());
            cellActions.Add("h", aRow => aRow.AddSpace());
            cellActions.Add("b", aRow => aRow.AddSpace());
            cellActions.Add("e", aRow => aRow.AddSpace());
            cellActions.Add("t", aRow => aRow.AddGoal());

            pieceActions.Add("w", aCell => aCell.WithWall());
            pieceActions.Add("h", aCell => aCell.WithPlayer());
            pieceActions.Add("b", aCell => aCell.WithBox());
        }

        public Board GetBoard(string gameName, int level)
        {
            var info = Application.GetResourceStream(new Uri(string.Format("Sokoban;component/Resources/Levels/{0}", gameName), UriKind.Relative));
            var doc = XDocument.Load(info.Stream);

            var boardBuilder = new BoardBuilder(messageBus);

            var track = doc.Descendants("track").Take(level).Last();
            foreach (var line in track.Descendants("line"))
            {
                boardBuilder.AddNewRow();

                foreach (var cell in line.Descendants())
                {
                    string cellKey = cell.Name.LocalName;
                    Action<IBuildRow> cellAction;
                    if (cellActions.TryGetValue(cellKey, out cellAction)) cellAction(boardBuilder);

                    var incAttribute = cell.Attributes()
                        .Where(anAttribute => anAttribute.Name.LocalName == "inc" && !string.IsNullOrEmpty(anAttribute.Value))
                        .FirstOrDefault();

                    string pieceKey = cellKey;
                    if (!ReferenceEquals(incAttribute, null)) pieceKey = incAttribute.Value;
                    Action<IBuildBoardAndRowAndCell> pieceAction;
                    if (pieceActions.TryGetValue(pieceKey, out pieceAction)) pieceAction((IBuildBoardAndRowAndCell)boardBuilder);
                }
            }

            return ((IBuildBoard)boardBuilder).Build();
        }
    }
}
