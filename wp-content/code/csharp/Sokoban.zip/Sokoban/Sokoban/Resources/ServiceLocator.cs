﻿using Sokoban.Infrastructure;
using Microsoft.Practices.Unity;
using Sokoban.ViewModels;
using Sokoban.Model;

namespace Sokoban.Resources
{
    public class ServiceLocator
    {
        public static ServiceLocator Instance { get; set; }

        private readonly IUnityContainer container;

		public ServiceLocator()
		{
		}
		
        public ServiceLocator(IUnityContainer container)
        {
            this.container = container;
        }

        IUnityContainer Container
        {
            get { return container; }
        }

        public IMessageBus MessageBus
        {
            get { return Container.Resolve<IMessageBus>(); }
        }

        public IGameRepository GameRepository
        {
            get { return Container.Resolve<IGameRepository>(); }
        }

        public GameViewModel GameViewModel
        {
            get { return Container.Resolve<GameViewModel>(); }
        }

        public CellViewModel CellViewModel
        {
            get { return Container.Resolve<CellViewModel>(); }
        }
    }
}
