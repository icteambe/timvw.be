﻿using System.Windows;
using System.Windows.Interactivity;
using System.Windows.Input;
using System.Windows.Data;

namespace Sokoban.Infrastructure
{
    public class InvokeCommandAction : TriggerAction<FrameworkElement>
    {
        public string CommandName { get; set; }

        protected override void Invoke(object parameter)
        {
            var viewModel = AssociatedObject.DataContext;
            GetCommandAndExecuteIt(viewModel, CommandName);
        }

        void GetCommandAndExecuteIt(object viewModel, string commandName)
        {
            var command = viewModel.GetPropertyValue<ICommand>(commandName);
            if (command.CanExecute(null)) command.Execute(null);
        }
    }
}
