﻿namespace Sokoban.Infrastructure
{
    public interface IListener { }

    public interface IListener<TMessage> : IListener
        where TMessage : Message
    {
        void Handle(TMessage message);
    }
}
