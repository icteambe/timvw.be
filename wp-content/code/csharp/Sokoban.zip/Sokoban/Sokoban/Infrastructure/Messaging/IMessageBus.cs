﻿namespace Sokoban.Infrastructure
{
    public interface IMessageBus
    {
        void Publish<TMessage>(TMessage message) where TMessage : Message;
        void Publish<TMessage>() where TMessage : Message, new();

        void Subscribe<TMessage>(IListener<TMessage> listener) where TMessage : Message;
        void Unsubscribe<TMessage>(IListener<TMessage> listener) where TMessage : Message;
    }
}
