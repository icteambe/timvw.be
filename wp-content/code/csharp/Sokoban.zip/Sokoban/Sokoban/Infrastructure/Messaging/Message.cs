﻿namespace Sokoban.Infrastructure
{
    public class Message
    {
    }
}
