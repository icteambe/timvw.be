﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Sokoban.Infrastructure
{
    public class MessageBus : IMessageBus
    {
        private readonly Dictionary<Type, List<IListener>> allListeners = new Dictionary<Type, List<IListener>>();
        private readonly object allListenersLock = new object();

        public void Publish<TMessage>(TMessage message) where TMessage : Message
        {
            var messageType = typeof(TMessage);
            List<IListener> messageListeners;

            lock (allListenersLock)
            {
                if (!allListeners.TryGetValue(messageType, out messageListeners)) return;
                foreach (IListener<TMessage> messageListener in messageListeners) messageListener.Handle(message);
            }
        }

        public void Publish<TMessage>() where TMessage : Message, new()
        {
            Publish(new TMessage());
        }

        public void Subscribe<TMessage>(IListener<TMessage> listener) where TMessage : Message
        {
            var messageType = typeof(TMessage);
            List<IListener> messageListeners;

            lock (allListenersLock)
            {
                if (!allListeners.TryGetValue(messageType, out messageListeners))
                {
                    messageListeners = new List<IListener>();
                    allListeners[messageType] = messageListeners;
                }

                messageListeners.Add(listener);
            }
        }

        public void Unsubscribe<TMessage>(IListener<TMessage> listener) where TMessage : Message
        {
            var messageType = typeof(TMessage);
            List<IListener> messageListeners;

            lock (allListenersLock)
            {
                if (!allListeners.TryGetValue(messageType, out messageListeners)) return;
                messageListeners.Remove(listener);
            }
        }
    }
}