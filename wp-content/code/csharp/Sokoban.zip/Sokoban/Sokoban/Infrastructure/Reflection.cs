﻿namespace Sokoban.Infrastructure
{
    public static class Reflection
    {
        public static T GetPropertyValue<T>(this object source, string propertyName)
        {
            return (T)source.GetType().GetProperty(propertyName).GetValue(source, null);
        }
    }
}
