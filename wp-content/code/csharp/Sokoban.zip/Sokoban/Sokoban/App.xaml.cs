﻿using System.Windows;
using Sokoban.Views;
using Sokoban.Resources;

namespace Sokoban
{
    public partial class App
    {
        public App()
        {
            Startup += Application_Startup;
            InitializeComponent();
        }

        void Application_Startup(object sender, StartupEventArgs e)
        {
            new BootsTrapper().Run();

            var gameView = new GameView();
            gameView.DataContext = ServiceLocator.Instance.GameViewModel;
            RootVisual = gameView;
        }
    }
}